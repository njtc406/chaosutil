/*
 * Copyright (c) 2023. YR. All rights reserved
 */

// Package server
// 模块名: 模块名
// 功能描述: 描述
// 作者:  yr  2023/6/2 0002 0:37
// 最后更新:  yr  2023/6/2 0002 0:37
package main

import (
	"fmt"
	"github.com/njtc406/chaosutil/rpc"
	"github.com/njtc406/chaosutil/rpc/server"
	"os"
	"os/signal"
	"syscall"
	"test/rpc/handler"
)

var closeCh = make(chan os.Signal, 0)

func main() {
	signal.Notify(closeCh, syscall.SIGTERM, syscall.SIGQUIT, syscall.SIGINT)
	conf := &rpc.EtcdConf{
		BasePath:    "/test",
		ServiceAddr: "192.168.2.157:4001",
		Addr:        []string{"192.168.2.101:2379"},
	}
	rpcServer := server.NewRPCService("127.0.0.1:4001", nil, conf)
	svcName := "aaa"
	err := rpcServer.RegisterService(&svcName, new(handler.AAA), false)
	if err != nil {
		fmt.Println("register", err)
		return
	}
	err = rpcServer.Init()
	if err != nil {
		fmt.Println("init", err)
		return
	}
	err = rpcServer.Start()
	if err != nil {
		fmt.Println("start", err)
		return
	}

	fmt.Println("---------------")
	fmt.Println(fmt.Sprintf("receive %v", <-closeCh))
	fmt.Println("%%%%%%%%%%%%%%%%%%%%%%%%")
	err = rpcServer.Stop()
	if err != nil {
		fmt.Println("stop", err)
		return
	}
	fmt.Println("====================")
}
