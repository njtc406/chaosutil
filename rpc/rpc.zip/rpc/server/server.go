package main

import (
	`fmt`
	`github.com/njtc406/chaosutil/rpc`
	`github.com/njtc406/chaosutil/rpc/server`
	`test/rpc/handler`
)

func main() {
	svr, err := server.NewETCDRpcxServer("tcp@192.168.0.106:8001", &rpc.EtcdConf{
		BasePath: "/test",
		Addr:     []string{"192.168.0.103:2379"},
	})
	if err != nil {
		fmt.Println(err)
		return
	}

	if err = svr.Serve("tcp", "0.0.0.0:8001"); err != nil {
		fmt.Println(err)
	}
}

func init() {
	server.RegisterService("aaa", new(handler.AAA), false)
}
