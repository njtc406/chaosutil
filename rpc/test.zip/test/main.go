package main

import (
	`io`
	`os`
)

func main() {
	writer := os.Stdout

	writer.Write([]byte{'a', 'b', 'c'})

	//writer1 := io.Writer(os.DevNull)
	//writer1.Write([]byte{'1', '2', '3'})

	writer2 := io.Discard
	writer2.Write([]byte{'r', 's', 't'})
}
