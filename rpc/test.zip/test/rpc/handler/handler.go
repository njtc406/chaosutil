package handler

import (
	`context`
)

type Args struct {
	Name string
}

type Reply struct {
	Answer string
}

type AAA struct {
}

func (a *AAA) Hi(ctx context.Context, args *Args, r *Reply) error {
	r.Answer = "hi " + args.Name
	return nil
}
