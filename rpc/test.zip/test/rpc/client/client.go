package main

import (
	`context`
	`fmt`
	`github.com/njtc406/chaosutil/rpc`
	`github.com/njtc406/chaosutil/rpc/client`
	`test/rpc/handler`
)

func main() {

	cli, err := client.NewRpcXClientUseEtcd(&rpc.EtcdConf{
		BasePath:    "/test",
		ServicePath: "",
		Addr:        []string{"192.168.0.103:2379"},
	}, nil)
	if err != nil {
		fmt.Printf("failed to create rpc client: %v", err)
		return
	}

	reply := &handler.Reply{}
	err = cli.Call(context.Background(), "aaa.Hi", &handler.Args{Name: "lili"}, reply)
	if err != nil {
		fmt.Printf("failed to call rpc service: %v", err)
		return
	}

	fmt.Printf("rpc service reply: %v", reply.Answer)
}
